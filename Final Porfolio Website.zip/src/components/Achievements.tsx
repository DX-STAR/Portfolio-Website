import React, { useState, useEffect } from 'react';
import { Award, ChevronLeft, ChevronRight } from 'lucide-react';

const achievements = [
  {
    title: 'First Place - National AI Hackathon',
    description: 'Developed an innovative AI solution for healthcare diagnostics',
    date: '2024',
    image: 'https://images.unsplash.com/photo-1567427017947-545c5f8d16ad?auto=format&fit=crop&q=80&w=500'
  },
  {
    title: 'Research Paper Publication',
    description: 'Published research on machine learning applications in climate change',
    date: '2023',
    image: 'https://images.unsplash.com/photo-1456324504439-367cee3b3c32?auto=format&fit=crop&q=80&w=500'
  },
  {
    title: 'Google Cloud Certification',
    description: 'Achieved Professional Data Engineer certification',
    date: '2023',
    image: 'https://images.unsplash.com/photo-1517245386807-bb43f82c33c4?auto=format&fit=crop&q=80&w=500'
  }
];

const Achievements = () => {
  const [currentSlide, setCurrentSlide] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % achievements.length);
    }, 5000);
    return () => clearInterval(timer);
  }, []);

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % achievements.length);
  };

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev - 1 + achievements.length) % achievements.length);
  };

  return (
    <section id="achievements" className="py-20 bg-gray-50 dark:bg-gray-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">Achievements</h2>
          <p className="text-lg text-gray-600 dark:text-gray-300">
            Recognition and milestones in my journey
          </p>
        </div>

        <div className="relative">
          <div className="overflow-hidden rounded-xl">
            <div
              className="flex transition-transform duration-500 ease-in-out"
              style={{ transform: `translateX(-${currentSlide * 100}%)` }}
            >
              {achievements.map((achievement) => (
                <div
                  key={achievement.title}
                  className="w-full flex-shrink-0"
                >
                  <div className="bg-white dark:bg-gray-800 rounded-xl shadow-md overflow-hidden mx-2">
                    <div className="md:flex">
                      <div className="md:w-1/2">
                        <img
                          src={achievement.image}
                          alt={achievement.title}
                          className="h-64 w-full object-cover"
                        />
                      </div>
                      <div className="p-8 md:w-1/2">
                        <div className="flex items-center mb-4">
                          <Award className="w-6 h-6 text-yellow-500 mr-2" />
                          <span className="text-sm text-yellow-500">{achievement.date}</span>
                        </div>
                        <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-4">
                          {achievement.title}
                        </h3>
                        <p className="text-gray-600 dark:text-gray-300">
                          {achievement.description}
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <button
            onClick={prevSlide}
            className="absolute left-0 top-1/2 -translate-y-1/2 p-2 bg-white/80 dark:bg-gray-800/80 rounded-full shadow-md hover:bg-white dark:hover:bg-gray-800 transition-colors duration-200"
          >
            <ChevronLeft className="w-6 h-6 text-gray-900 dark:text-white" />
          </button>
          <button
            onClick={nextSlide}
            className="absolute right-0 top-1/2 -translate-y-1/2 p-2 bg-white/80 dark:bg-gray-800/80 rounded-full shadow-md hover:bg-white dark:hover:bg-gray-800 transition-colors duration-200"
          >
            <ChevronRight className="w-6 h-6 text-gray-900 dark:text-white" />
          </button>

          <div className="flex justify-center mt-4 space-x-2">
            {achievements.map((_, index) => (
              <button
                key={index}
                onClick={() => setCurrentSlide(index)}
                className={`w-3 h-3 rounded-full transition-colors duration-200 ${
                  currentSlide === index
                    ? 'bg-yellow-500'
                    : 'bg-gray-300 dark:bg-gray-600'
                }`}
              />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default Achievements;